﻿namespace SchoolAppMvcsCore.Models
{
    public class LoginModel
    {
        public string UserName { get; set; }
    }

}
