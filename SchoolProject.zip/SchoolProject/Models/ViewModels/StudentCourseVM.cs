﻿namespace SchoolAppMvcsCore.Models.ViewModels
{
    public class StudentCourseVM
    {
        public List<Student> Students { get; set; }
        public List<Course> Courses { get; set; }
    }
}
